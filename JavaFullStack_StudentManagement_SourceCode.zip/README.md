# Java Full-Stack Student Management System

## Technologies
- Java 17
- Spring Boot
- Spring JDBC
- MySQL
- Maven
- HTML, CSS, JavaScript
- REST API
- MVC-style Controller -> Service -> DAO architecture

## Setup

1. Install JDK 17+, Maven, and MySQL.
2. Run `database.sql` in MySQL.
3. Open `src/main/resources/application.properties`.
4. Replace `YOUR_MYSQL_PASSWORD` with your MySQL root password.
5. From the project folder run:

   mvn spring-boot:run

6. Open:

   http://localhost:8080

## API endpoints

GET    /api/students
GET    /api/students/{id}
POST   /api/students
PUT    /api/students/{id}
DELETE /api/students/{id}

## Architecture

Frontend -> REST Controller -> Service -> DAO -> Spring JDBC -> MySQL
