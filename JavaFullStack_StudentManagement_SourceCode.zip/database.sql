CREATE DATABASE IF NOT EXISTS studentdb;
USE studentdb;

CREATE TABLE IF NOT EXISTS student (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    course VARCHAR(100) NOT NULL
);

INSERT INTO student (name, email, course)
VALUES
('Sravya', 'sravya@example.com', 'Java Full Stack'),
('Ravi', 'ravi@example.com', 'Computer Science');
