package com.example.student.service;

import com.example.student.dao.StudentDAO;
import com.example.student.model.Student;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    private final StudentDAO dao;

    public StudentService(StudentDAO dao) {
        this.dao = dao;
    }

    public Student add(Student s) { return dao.save(s); }
    public List<Student> getAll() { return dao.findAll(); }
    public Student getById(int id) { return dao.findById(id); }

    public boolean update(int id, Student s) {
        return dao.update(id, s) > 0;
    }

    public boolean delete(int id) {
        return dao.delete(id) > 0;
    }
}
