package com.example.student.dao;

import com.example.student.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;

@Repository
public class StudentDAO {
    private final JdbcTemplate jdbc;

    public StudentDAO(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public Student save(Student s) {
        String sql = "INSERT INTO student(name,email,course) VALUES (?,?,?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbc.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, s.getName());
            ps.setString(2, s.getEmail());
            ps.setString(3, s.getCourse());
            return ps;
        }, keyHolder);

        s.setId(keyHolder.getKey().intValue());
        return s;
    }

    public List<Student> findAll() {
        return jdbc.query(
            "SELECT id,name,email,course FROM student ORDER BY id",
            (rs, rowNum) -> new Student(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("course")
            )
        );
    }

    public Student findById(int id) {
        List<Student> result = jdbc.query(
            "SELECT id,name,email,course FROM student WHERE id=?",
            (rs, rowNum) -> new Student(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("course")
            ),
            id
        );
        return result.isEmpty() ? null : result.get(0);
    }

    public int update(int id, Student s) {
        return jdbc.update(
            "UPDATE student SET name=?, email=?, course=? WHERE id=?",
            s.getName(), s.getEmail(), s.getCourse(), id
        );
    }

    public int delete(int id) {
        return jdbc.update("DELETE FROM student WHERE id=?", id);
    }
}
