const api = "/api/students";
const form = document.getElementById("studentForm");
const message = document.getElementById("message");

async function loadStudents() {
    const res = await fetch(api);
    const students = await res.json();
    const table = document.getElementById("studentTable");
    table.innerHTML = students.map(s => `
        <tr>
            <td>${s.id}</td>
            <td>${escapeHtml(s.name)}</td>
            <td>${escapeHtml(s.email)}</td>
            <td>${escapeHtml(s.course)}</td>
            <td>
                <button onclick="editStudent(${s.id})">Edit</button>
                <button class="delete" onclick="deleteStudent(${s.id})">Delete</button>
            </td>
        </tr>`).join("");
}

form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("studentId").value;
    const student = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        course: document.getElementById("course").value
    };

    const res = await fetch(id ? `${api}/${id}` : api, {
        method: id ? "PUT" : "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(student)
    });

    if (res.ok) {
        showMessage(id ? "Student updated." : "Student added.");
        resetForm();
        loadStudents();
    } else {
        showMessage("Operation failed.");
    }
});

async function editStudent(id) {
    const res = await fetch(`${api}/${id}`);
    if (!res.ok) return;
    const s = await res.json();
    document.getElementById("studentId").value = s.id;
    document.getElementById("name").value = s.name;
    document.getElementById("email").value = s.email;
    document.getElementById("course").value = s.course;
}

async function deleteStudent(id) {
    if (!confirm("Delete this student?")) return;
    const res = await fetch(`${api}/${id}`, {method: "DELETE"});
    if (res.ok) {
        showMessage("Student deleted.");
        loadStudents();
    }
}

document.getElementById("cancelBtn").onclick = resetForm;

function resetForm() {
    form.reset();
    document.getElementById("studentId").value = "";
}

function showMessage(text) {
    message.textContent = text;
    setTimeout(() => message.textContent = "", 2500);
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, c =>
        ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

loadStudents();
